export interface PromptItem {
  prompt: string;
}

export type Language = 'IDN' | 'ENG';
